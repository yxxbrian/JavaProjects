/**
 * Created by Brian_PC on 2017/7/19.
 */
public enum CardType {
    A,
    B,
    C,
    D
}
